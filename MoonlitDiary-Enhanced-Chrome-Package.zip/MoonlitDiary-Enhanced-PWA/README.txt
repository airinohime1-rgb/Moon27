MOONLIT DIARY — ENHANCED CHROME / HOME-SCREEN EDITION

WHAT IS INCLUDED
- index.html: the upgraded diary app
- manifest.webmanifest and service-worker.js: install and offline app-shell support
- icons/: home-screen icons

WHAT'S NEW
- 39 typefaces with a searchable font browser, live previews and a recently used list
- Handlee and Cabin Sketch are featured in the font browser
- Additional handwriting, Gothic, classic, Japanese and sans-serif fonts
- Per-page font size and font-weight controls
- 23 paper themes, grouped into Gothic, Japanese, Cute, Colors, Daily Life, Garden and Scenery
- Three reading layouts: Pages (the original page-turning book), Grid and List
- A relaxing-sounds mixer with 16 synthesised sounds, 5 mix presets, pause/stop controls and 5/15/30/60-minute sleep timers
- Grouped ink-colour palettes for Colors, Cute, Daily Life, Garden, Scenery, Gothic and Japanese
- Optional four-digit privacy PIN. This is a convenience lock only; it does not encrypt diary data.
- Copy Backup / Restore from Text for all diaries
- Light/dark app display mode, multiple diaries, stickers, formatting tools and autosave remain available

OPEN THE DIARY LOCALLY
1. Unzip the download.
2. Open the MoonlitDiary-Enhanced-PWA folder.
3. Open index.html in Chrome or another modern browser.
4. The diary itself works locally. Google Fonts need an internet connection to download; fallback fonts are used offline.

INSTALL AS AN APP ON ANDROID / GOOGLE CHROME
Home-screen installation requires the files to be hosted on an HTTPS website. Opening index.html directly is fine for local use, but browser app installation and offline app-shell caching require HTTPS (or localhost for testing).

EASIEST ROUTE: GITHUB PAGES
1. Create a new repository on GitHub.
2. Upload the CONTENTS of this folder to the repository root: index.html, manifest.webmanifest, service-worker.js and icons/ (README.txt is optional). Do not upload only the outer folder.
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select the main branch and /(root), then Save.
5. Open the published HTTPS website in Google Chrome on your Android phone.
6. Tap the three-dot menu and choose Install app or Add to Home screen.

BACK UP YOUR WRITING
1. Tap Diaries in Moonlit Diary.
2. Choose Backup / Restore.
3. Tap Copy backup and keep the copied text somewhere private.
4. To restore later, open the same panel, paste the backup text and tap Restore from text. Restoring replaces the currently saved diary collection.

SAVING AND PRIVACY
Entries autosave in browser storage on the same device/browser. They are not automatically synced between devices. The PIN is a casual access screen, not encryption. Keep backups somewhere private and do not use the app PIN as a substitute for protecting sensitive information.
